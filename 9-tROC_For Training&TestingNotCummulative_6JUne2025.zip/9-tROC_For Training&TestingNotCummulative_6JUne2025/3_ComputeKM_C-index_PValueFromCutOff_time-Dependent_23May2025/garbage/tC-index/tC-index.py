import pandas as pd
import numpy as np
from lifelines.utils import concordance_index
from sksurv.util import Surv
from sksurv.metrics import concordance_index_ipcw

# ===============================
# Parameters
# ===============================
CUTOFF = 0.08
TRAIN_FILE = "1_Training_With_RiskGroups.csv"
VALID_FILE = "2_Validation_With_RiskGroups.csv"

# ===============================
# Load Data
# ===============================
train_df = pd.read_csv(TRAIN_FILE)
valid_df = pd.read_csv(VALID_FILE)

# ===============================
# Assign Risk Groups (Optional)
# ===============================
def assign_risk_group(df, cutoff):
    df = df.copy()
    df["risk_group"] = np.where(df["log_risk_score"] >= cutoff, "High Risk", "Low Risk")
    return df

train_df = assign_risk_group(train_df, CUTOFF)
valid_df = assign_risk_group(valid_df, CUTOFF)

# ===============================
# Harrell's C-index
# ===============================
# Higher score = higher risk → negate if higher score means better survival
harrell_train_c = concordance_index(train_df["time"], -train_df["log_risk_score"], train_df["event"])
harrell_valid_c = concordance_index(valid_df["time"], -valid_df["log_risk_score"], valid_df["event"])

print(f"Harrell's C-index (Training):  {harrell_train_c:.4f}")
print(f"Harrell's C-index (Validation): {harrell_valid_c:.4f}")

# ===============================
# Time-dependent C-index (IPCW)
# ===============================
# Convert to structured arrays for scikit-survival
y_train = Surv.from_dataframe("event", "time", train_df)
y_valid = Surv.from_dataframe("event", "time", valid_df)

# Scores: higher = higher risk → negate if needed
scores_valid = -valid_df["log_risk_score"]

# Compute time-dependent C-index
time_dep_c = concordance_index_ipcw(y_train, y_valid, scores_valid)[0]
print(f"Time-dependent C-index (Validation): {time_dep_c:.4f}")
