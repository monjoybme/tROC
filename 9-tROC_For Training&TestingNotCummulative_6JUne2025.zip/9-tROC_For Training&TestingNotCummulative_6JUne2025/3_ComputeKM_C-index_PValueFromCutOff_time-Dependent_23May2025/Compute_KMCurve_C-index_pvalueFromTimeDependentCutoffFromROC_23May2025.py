import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter
from lifelines.statistics import logrank_test
from lifelines.utils import concordance_index

# ============================
# Load data
# ============================
training_data = pd.read_csv("1_MergedCensoring_TRAINIG_RiskScore_File.csv")  # must include: log_risk_score, event, time
validation_data = pd.read_csv("2_MergeCensoring_TESTING_RiskScore_File.csv")

# Optimal cutoff from ROC (e.g., Youden's index)
optimal_cutoff = 0.08  # Replace with your computed value

# ========================================================
# Step 1: Assign risk groups based on the cutoff
# ========================================================
def assign_risk_group(data, cutoff):
    data = data.copy()
    data['risk_group'] = np.where(data['log_risk_score'] >= cutoff, 'High Risk', 'Low Risk')
    return data

training_data = assign_risk_group(training_data, optimal_cutoff)
validation_data = assign_risk_group(validation_data, optimal_cutoff)

# ========================================================
# Step 2: Plot and save Kaplan-Meier Curves
# ========================================================
def plot_and_save_kaplan_meier(data, title, filename):
    kmf = KaplanMeierFitter()
    plt.figure(figsize=(8, 6))

    for group in ['Low Risk', 'High Risk']:
        mask = data['risk_group'] == group
        kmf.fit(data.loc[mask, 'time'], event_observed=data.loc[mask, 'event'], label=group)
        kmf.plot_survival_function(ci_show=True)

    plt.title(title)
    plt.xlabel("Time (months)")
    plt.ylabel("Survival Probability")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.savefig(filename)  # Save plot to file
    plt.close()

    # Log-rank test
    low_risk = data[data['risk_group'] == 'Low Risk']
    high_risk = data[data['risk_group'] == 'High Risk']
    result = logrank_test(
        low_risk['time'], high_risk['time'],
        event_observed_A=low_risk['event'],
        event_observed_B=high_risk['event']
    )
    print(f"{title} - Log-rank p-value: {result.p_value:.4f}")
    return result.p_value

# ========================================================
# Step 3: Calculate Harrell's C-index
# ========================================================
def compute_c_index(data, dataset_name):
    # Assumes higher score = higher risk (worse survival); if opposite, remove minus sign
    c_index = concordance_index(data["time"], -data["log_risk_score"], data["event"])
    print(f"{dataset_name} - Harrell's C-index: {c_index:.4f}")
    return c_index

# ========================================================
# Step 4: Run for both datasets
# ========================================================
print("Training Set:")
plot_and_save_kaplan_meier(training_data, "Training Set: Survival by Risk Group", "training_km_curve.png")
compute_c_index(training_data, "Training Set")

print("\nValidation Set:")
plot_and_save_kaplan_meier(validation_data, "Validation Set: Survival by Risk Group", "validation_km_curve.png")
compute_c_index(validation_data, "Validation Set")

# ========================================================
# Step 5: Save datasets with risk group to new CSV files
# ========================================================
training_data.to_csv("1_Training_With_RiskGroups.csv", index=False)
validation_data.to_csv("2_Validation_With_RiskGroups.csv", index=False)
