import pandas as pd

# Load the two CSV files
file1 = pd.read_csv('log_partial_risk_scores_final-Training.csv')
file2 = pd.read_csv('ForMonjoy_SurvivalLessThan120Months.csv')

# Ensure consistent column naming (some columns may have trailing spaces or different casing)
file1.columns = file1.columns.str.strip()
file2.columns = file2.columns.str.strip()

# Perform the merge on SLIDE_ID
merged = pd.merge(file1, file2[['SLIDE_ID', 'Sherlock_PID']], on='SLIDE_ID', how='left')

# Save the merged result to a new CSV
merged.to_csv('log_partial_risk_scores_final-Training_with_PID.csv', index=False)
