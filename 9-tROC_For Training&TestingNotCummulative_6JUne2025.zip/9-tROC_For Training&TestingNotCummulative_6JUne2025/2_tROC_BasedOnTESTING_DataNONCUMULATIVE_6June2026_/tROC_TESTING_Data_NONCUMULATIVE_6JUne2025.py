import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sksurv.metrics import cumulative_dynamic_auc
from sksurv.util import Surv
from sklearn.metrics import roc_curve

RANDOM_STATE = 42

# --- BOOTSTRAP FUNCTION ---
def bootstrap_auc(y_surv, scores, t, n_bootstrap=1000, random_state=RANDOM_STATE):
    rng = np.random.default_rng(random_state)
    aucs = []
    n = len(scores)
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, n)
        y_surv_boot = y_surv[idx]
        scores_boot = scores[idx]
        _, auc = cumulative_dynamic_auc(y_surv_boot, y_surv_boot, scores_boot, [t])
        aucs.append(float(auc))
    lower = np.percentile(aucs, 2.5)
    upper = np.percentile(aucs, 97.5)
    return lower, upper, aucs

# Load data
df = pd.read_csv("Survival-Sherlock-Lung_TESTING_Data_with_PID.csv", sep=",")
df.columns = df.columns.str.strip()

# Survival object and risk scores
y_surv = Surv.from_dataframe("event", "time", df)
scores = df["log_risk_score"].values

max_time = df["time"].max()
safe_max_time = np.nextafter(120.0, 0)

time_points = [t for t in np.arange(12, 121, 12) if t < max_time]
if np.isclose(max_time, 120):
    time_points.append(safe_max_time)

# Data collectors
cutoff_data = []               # For optimal cutoffs
all_cut_points_data = []       # For all thresholds

# Plot setup
plt.figure(figsize=(10, 7))

for t in time_points:
    # AUC and CI
    _, auc_val = cumulative_dynamic_auc(y_surv, y_surv, scores, [t])
    auc_val = float(auc_val)
    ci_lower, ci_upper, _ = bootstrap_auc(y_surv, scores, t)

    # Binary label for ROC
    binary_event = [(e and time <= t) for e, time in zip(df["event"], df["time"])]
    fpr, tpr, thresholds = roc_curve(binary_event, scores)
    youden_index = tpr - fpr
    optimal_idx = np.argmax(youden_index)
    optimal_cutoff = thresholds[optimal_idx]

    # --- Store optimal cutpoint ---
    cutoff_data.append({
        "time_months": round(t, 4),
        "AUC": round(auc_val, 4),
        "AUC_CI_lower": round(ci_lower, 4),
        "AUC_CI_upper": round(ci_upper, 4),
        "optimal_cutoff": round(optimal_cutoff, 4),
        "youden_index": round(youden_index[optimal_idx], 4)
    })

    # --- Store all cut points ---
    for f, tp, thr, y_idx in zip(fpr, tpr, thresholds, youden_index):
        all_cut_points_data.append({
            "time_months": round(t, 4),
            "AUC": round(auc_val, 4),
            "AUC_CI_lower": round(ci_lower, 4),
            "AUC_CI_upper": round(ci_upper, 4),
            "threshold": round(thr, 6),
            "FPR": round(f, 6),
            "TPR": round(tp, 6),
            "youden_index": round(y_idx, 6)
        })

    # Plot ROC
    label_time = "120" if np.isclose(t, safe_max_time) else str(int(t))
    plt.plot(fpr, tpr, label=f"{label_time} mo (AUC = {auc_val:.2f} [{ci_lower:.2f}-{ci_upper:.2f}])")

# Final plot settings
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("Time-dependent ROC Curves on TESTING NON CUMULATIVE Data")
plt.legend()
plt.tight_layout()
plt.savefig("time_dependent_ROC_With_CI.png", dpi=300)
plt.show()

# --- Save CSVs ---

# 1. Optimal cutoffs
cutoff_df = pd.DataFrame(cutoff_data)
cutoff_df.to_csv("optimal_cutoffs_youden_index_Non_Cumulative_TESTING_Data_6June2025.csv", index=False)

# 2. All ROC cut points
cut_points_df = pd.DataFrame(all_cut_points_data)
cut_points_df.to_csv("all_ROC_cutpoints_per_timepoint_TESTING_Data_6June2025.csv", index=False)

# Done
print("✅ Time-dependent ROC plot saved as 'time_dependent_ROC_With_CI.png'")
print("✅ Optimal cutoffs saved in 'optimal_cutoffs_youden_index_Non_Cumulative_TESTING_Data_6June2025.csv'")
print("✅ All ROC cut points saved in 'all_ROC_cutpoints_per_timepoint_TESTING_Data_6June2025.csv'")
