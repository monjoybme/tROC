import pandas as pd

# Load the two CSV files
file1 = pd.read_csv('Survival-Sherlock-Lung_TESTING_Data.csv')
file2 = pd.read_csv('ForMonjoy_SurvivalLessThan120Months.csv')

# Ensure consistent column naming
file1.columns = file1.columns.str.strip()
file2.columns = file2.columns.str.strip()

# Remove duplicates in the source files based on SLIDE_ID
file1 = file1.drop_duplicates(subset='SLIDE_ID')
file2 = file2.drop_duplicates(subset='SLIDE_ID')

# Perform the merge on SLIDE_ID
merged = pd.merge(file1, file2[['SLIDE_ID', 'Sherlock_PID']], on='SLIDE_ID', how='left')

# Optional: Ensure merged file has no duplicate SLIDE_IDs
merged = merged.drop_duplicates(subset='SLIDE_ID')

# Save the merged result
merged.to_csv('l1_MergedCensoring_TRAINIG_RiskScore_File_with_PID.csv', index=False)
