import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sksurv.metrics import cumulative_dynamic_auc
from sksurv.util import Surv
from sklearn.metrics import roc_curve

# Load the dataset
df = pd.read_csv("1_MergedCensoring_TRAINIG_RiskScore_File.csv", sep=",")
df.columns = df.columns.str.strip()  # Clean column names

# Prepare survival data
y_surv = Surv.from_dataframe("event", "time", df)
scores = df["log_risk_score"].values

# Determine max follow-up time
max_time = df["time"].max()

# Define valid time points (every 12 months up to just before max follow-up time)
time_points = [t for t in np.arange(12, 121, 12) if t < max_time]


# Prepare to store cutoff results
cutoff_data = []

# Plot setup
plt.figure(figsize=(10, 7))

for t in time_points:
    # Compute AUC at time t
    _, auc_val = cumulative_dynamic_auc(y_surv, y_surv, scores, [t])

    # Create binary labels for events up to time t
    binary_event = [(e and time <= t) for e, time in zip(df["event"], df["time"])]
    fpr, tpr, thresholds = roc_curve(binary_event, scores)

    # Compute Youden index
    youden_index = tpr - fpr
    optimal_idx = np.argmax(youden_index)
    optimal_cutoff = thresholds[optimal_idx]

    # Save the results
    cutoff_data.append({
        "time_months": t,
        "AUC": round(float(auc_val), 4),
        "optimal_cutoff": round(optimal_cutoff, 4),
        "youden_index": round(youden_index[optimal_idx], 4)
    })

    # Plot ROC
    plt.plot(fpr, tpr, label=f"{t} mo (AUC = {auc_val:.2f})")

# Plot reference line
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("Time-dependent ROC Curves (up to 120 months)")
plt.legend()
plt.tight_layout()
plt.savefig("time_dependent_ROC_120mo.png", dpi=300)
plt.show()

# Save cutoff data to CSV
cutoff_df = pd.DataFrame(cutoff_data)
cutoff_df.to_csv("optimal_cutoffs_youden_index.csv", index=False)

print("✅ Time-dependent ROC plot saved as 'time_dependent_ROC_120mo.png'")
print("✅ Optimal cutoffs and Youden indices saved in 'optimal_cutoffs_youden_index.csv'")
