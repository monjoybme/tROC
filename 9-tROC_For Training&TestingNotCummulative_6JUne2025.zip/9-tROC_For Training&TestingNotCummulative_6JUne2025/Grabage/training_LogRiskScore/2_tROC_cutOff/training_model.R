# ====================
# TIME-DEPENDENT ROC AND SURVIVAL ANALYSIS
# ====================

# === Install and load packages ===
#install.packages(c("survival", "timeROC"))
library(survival)
library(timeROC)

# === Load your data ===
train_data <- read.csv("1_MergedCensoring_TRAINIG_RiskScore_File.csv")

# === Compute ROC at 60 months ===
roc <- timeROC(
  T = train_data$time,
  delta = train_data$status,
  marker = train_data$log_risk_score,
  cause = 1,
  times = 60,   # Must be a time point well-covered in your data
  iid = TRUE
)
str(roc)
# === Get Youden Index and optimal cutoff ===
youden_index <- roc$TPR - roc$FPR
optimal_idx <- which.max(youden_index)
cutoff <- roc$cut.values[optimal_idx]
cat("Optimal cutoff (Youden Index) at 60 months:", cutoff, "\n")

# === Assign High/Low risk groups ===
train_data$risk_group <- ifelse(train_data$log_risk_score >= cutoff, "High", "Low")

# === Kaplan-Meier curves ===
fit <- survfit(Surv(time, status) ~ risk_group, data = train_data)
plot(fit, col = c("blue", "red"), lwd = 2,
     main = "Kaplan-Meier Curves by Risk Group (Training)",
     xlab = "Time (months)", ylab = "Survival Probability")
legend("bottomleft", legend = c("Low Risk", "High Risk"),
       col = c("blue", "red"), lty = 1, lwd = 2)

# === Log-rank test ===
logrank_test <- survdiff(Surv(time, status) ~ risk_group, data = train_data)
print(logrank_test)

# === Save cutoff for test set use ===
save(cutoff, file = "cox_cutoff_only.RData")
