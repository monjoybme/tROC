
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sksurv.metrics import cumulative_dynamic_auc
from sksurv.util import Surv
from sklearn.metrics import roc_curve

# For reproducibility
RANDOM_STATE = 42

# --- BOOTSTRAP FUNCTION ---
def bootstrap_auc(y_surv, scores, t, n_bootstrap=1000, random_state=RANDOM_STATE):
    rng = np.random.default_rng(random_state)
    aucs = []
    n = len(scores)
    for _ in range(n_bootstrap):
        # Sample with replacement
        idx = rng.integers(0, n, n)
        y_surv_boot = y_surv[idx]
        scores_boot = scores[idx]
        # Compute AUC (train and test set are the same here)
        _, auc = cumulative_dynamic_auc(y_surv_boot, y_surv_boot, scores_boot, [t])
        aucs.append(float(auc))
    # Compute 95% CI
    lower = np.percentile(aucs, 2.5)
    upper = np.percentile(aucs, 97.5)
    return lower, upper, aucs

# Load the dataset
df = pd.read_csv("1_MergedCensoring_TRAINIG_RiskScore_File.csv", sep=",")
df.columns = df.columns.str.strip()  # Clean column names

# Prepare survival data
y_surv = Surv.from_dataframe("event", "time", df)
scores = df["log_risk_score"].values

# Determine max follow-up time
max_time = df["time"].max()
safe_max_time = np.nextafter(120.0, 0)  

print(f"Max follow-up time in dataset: {max_time:.4f}")

time_points = [t for t in np.arange(12, 121, 12) if t < max_time]

if np.isclose(max_time, 120):
    time_points.append(safe_max_time)  
    print(f"Included near-120 month point: {safe_max_time}")

print(f"Using time points: {time_points}")

# Prepare to store cutoff results
cutoff_data = []

# Plot setup
plt.figure(figsize=(10, 7))

for t in time_points:
    # Compute AUC at time t
    _, auc_val = cumulative_dynamic_auc(y_surv, y_surv, scores, [t])
    auc_val = float(auc_val)
    
    # --- BOOTSTRAP CI ---
    ci_lower, ci_upper, _ = bootstrap_auc(y_surv, scores, t, n_bootstrap=1000, random_state=RANDOM_STATE)
    
    # Create binary labels for events up to time t
    binary_event = [(e and time <= t) for e, time in zip(df["event"], df["time"])]
    fpr, tpr, thresholds = roc_curve(binary_event, scores)

    # Compute Youden index
    youden_index = tpr - fpr
    optimal_idx = np.argmax(youden_index)
    optimal_cutoff = thresholds[optimal_idx]

    # Save the results
    cutoff_data.append({
        "time_months": round(t, 4),
        "AUC": round(auc_val, 4),
        "AUC_CI_lower": round(ci_lower, 4),
        "AUC_CI_upper": round(ci_upper, 4),
        "optimal_cutoff": round(optimal_cutoff, 4),
        "youden_index": round(youden_index[optimal_idx], 4)
    })

    # Plot ROC
    label_time = "120" if np.isclose(t, safe_max_time) else str(int(t))
    plt.plot(fpr, tpr, label=f"{label_time} mo (AUC = {auc_val:.2f} [{ci_lower:.2f}-{ci_upper:.2f}])")

# Plot reference line
plt.plot([0, 1], [0, 1], 'k--')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("Time-dependent ROC Curves on TRAINING Data")
plt.legend()
plt.tight_layout()
plt.savefig("time_dependent_ROC_With_CI.png", dpi=300)
plt.show()

# Save cutoff data to CSV
cutoff_df = pd.DataFrame(cutoff_data)
cutoff_df.to_csv("optimal_cutoffs_youden_index.csv", index=False)

print("✅ Time-dependent ROC plot saved as 'time_dependent_ROC_120mo.png'")
print("✅ Optimal cutoffs and Youden indices saved in 'optimal_cutoffs_youden_index.csv'")
